# Tic_Tac_Toe

An unbeatable game of Tic Tac Toe. This tic-tac-toe game was developed using Android Studio, the official integrated development environment for Google's Android operating system, designed specifically for Android development. The game itself allows two humans (player X and player O) to compete again each other. The layout is very simple. A 9 square grid, where player X and player O compete against each other. Whenever there is a draw or someone wins, the game displays which player won along with the option to play the game again.

## Features
- Two Player.
- Restart Button.
- Auto Start.

More feature coming soon! This Game is Development Process!

For any kind of help, support, payment, suggestion and request ask me on Gmail / Telegram:

<a href="https://t.me/CyberClans"><img src="https://img.shields.io/badge/Telegram-Group%20Telegram%20Join-blue.svg?logo=telegram"></a>

## Follow on:
<p align="left">
<a href="https://github.com/palahsu"><img src="https://img.shields.io/badge/GitHub-Follow%20on%20GitHub-inactive.svg?logo=github"></a>
</p><p align="left">
<a href="https://www.facebook.com/aduri.knox01/"><img src="https://img.shields.io/badge/Facebook-Follow%20on%20Facebook-blue.svg?logo=facebook"></a>
</p><p align="left">
<a href="https://t.me/AD0000000"><img src="https://img.shields.io/badge/Telegram-Contact%20Telegram%20Profile-blue.svg?logo=telegram"></a>
</p><p align="left"> 

